﻿namespace FBLA
{
    partial class IOMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AccInput = new System.Windows.Forms.TextBox();
            this.AccText = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.Label();
            this.PasswordInput = new System.Windows.Forms.TextBox();
            this.Login = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.OpeningTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Setup = new System.Windows.Forms.Button();
            this.loadLabel = new System.Windows.Forms.Label();
            this.ErrorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // AccInput
            // 
            this.AccInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.AccInput.Location = new System.Drawing.Point(144, 105);
            this.AccInput.Name = "AccInput";
            this.AccInput.Size = new System.Drawing.Size(337, 26);
            this.AccInput.TabIndex = 0;
            // 
            // AccText
            // 
            this.AccText.AutoSize = true;
            this.AccText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.AccText.Location = new System.Drawing.Point(51, 105);
            this.AccText.Name = "AccText";
            this.AccText.Size = new System.Drawing.Size(30, 20);
            this.AccText.TabIndex = 1;
            this.AccText.Text = "ID:";
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Password.Location = new System.Drawing.Point(51, 140);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(82, 20);
            this.Password.TabIndex = 2;
            this.Password.Text = "Password:";
            // 
            // PasswordInput
            // 
            this.PasswordInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.PasswordInput.Location = new System.Drawing.Point(144, 140);
            this.PasswordInput.Name = "PasswordInput";
            this.PasswordInput.Size = new System.Drawing.Size(337, 26);
            this.PasswordInput.TabIndex = 1;
            // 
            // Login
            // 
            this.Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Login.Location = new System.Drawing.Point(155, 183);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(130, 35);
            this.Login.TabIndex = 4;
            this.Login.Text = "Log In";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.button1.Location = new System.Drawing.Point(311, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 35);
            this.button1.TabIndex = 5;
            this.button1.Text = "Create New Account";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // OpeningTitle
            // 
            this.OpeningTitle.AutoSize = true;
            this.OpeningTitle.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.OpeningTitle.Font = new System.Drawing.Font("Copperplate Gothic Bold", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpeningTitle.Location = new System.Drawing.Point(125, 42);
            this.OpeningTitle.Name = "OpeningTitle";
            this.OpeningTitle.Size = new System.Drawing.Size(366, 23);
            this.OpeningTitle.TabIndex = 6;
            this.OpeningTitle.Text = "FBLA-PBL School Ebook System";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FBLA.Properties.Resources.Color_FBLA_Logo;
            this.pictureBox1.Location = new System.Drawing.Point(55, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Setup
            // 
            this.Setup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Setup.Location = new System.Drawing.Point(233, 237);
            this.Setup.Name = "Setup";
            this.Setup.Size = new System.Drawing.Size(130, 35);
            this.Setup.TabIndex = 8;
            this.Setup.Text = "Setup Admin Key";
            this.Setup.UseVisualStyleBackColor = true;
            this.Setup.Click += new System.EventHandler(this.Setup_Click);
            // 
            // loadLabel
            // 
            this.loadLabel.AutoSize = true;
            this.loadLabel.Location = new System.Drawing.Point(431, 277);
            this.loadLabel.Name = "loadLabel";
            this.loadLabel.Size = new System.Drawing.Size(0, 13);
            this.loadLabel.TabIndex = 9;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(419, 237);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(0, 20);
            this.ErrorLabel.TabIndex = 10;
            // 
            // IOMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 299);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.loadLabel);
            this.Controls.Add(this.Setup);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.OpeningTitle);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.PasswordInput);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.AccText);
            this.Controls.Add(this.AccInput);
            this.Name = "IOMain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox AccInput;
        private System.Windows.Forms.Label AccText;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.TextBox PasswordInput;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label OpeningTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Setup;
        private System.Windows.Forms.Label loadLabel;
        private System.Windows.Forms.Label ErrorLabel;
    }
}

