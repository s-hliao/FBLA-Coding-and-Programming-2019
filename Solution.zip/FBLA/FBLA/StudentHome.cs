﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class StudentHome : Form {
        public Account acc;
        public IOMain main;

        public StudentHome(Account a, IOMain main) {
            this.acc = a;
            this.main = main;


            InitializeComponent();
        }

        private void StudentHome_Load(object sender, EventArgs e) {
            WelcomeLabel.Text = "Welcome, " + acc.firstName + " " + acc.lastName;

        }

        private void StudentHome_FormClosing(object sender, FormClosingEventArgs e) {
            main.Close();
        }

        private void Return_Click(object sender, EventArgs e) {
            main.Show();
            this.Close();
            //show login screen
        }

        private void button4_Click(object sender, EventArgs e) {
            Settings changeSettings = new Settings(acc);
            changeSettings.Show();
            //create settings dialog box
        }

        private void button1_Click(object sender, EventArgs e) {
            BookCheck check = new BookCheck(acc); //create window to view or return borrowed books 
            check.Show();
        }

        private void button2_Click(object sender, EventArgs e) {
            CheckOut checkout = new CheckOut(acc); //checkout books using accession numbers
            checkout.Show();
        }

        private void Help_Click(object sender, EventArgs e) {
            Help helpWindow = new Help(); //open up help window
            helpWindow.Show();

        }
    }
}
