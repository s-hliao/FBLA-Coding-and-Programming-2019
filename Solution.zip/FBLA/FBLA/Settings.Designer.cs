﻿namespace FBLA {
    partial class Settings {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.Identity = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.Grade = new System.Windows.Forms.Label();
            this.OG = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Original = new System.Windows.Forms.TextBox();
            this.Confirm = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Nam = new System.Windows.Forms.Label();
            this.Change = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(167, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Account Settings";
            // 
            // Identity
            // 
            this.Identity.AutoSize = true;
            this.Identity.Location = new System.Drawing.Point(46, 93);
            this.Identity.Name = "Identity";
            this.Identity.Size = new System.Drawing.Size(30, 20);
            this.Identity.TabIndex = 13;
            this.Identity.Text = "ID:";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(46, 125);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(109, 20);
            this.Date.TabIndex = 121;
            this.Date.Text = "Date Created:";
            // 
            // Grade
            // 
            this.Grade.AutoSize = true;
            this.Grade.Location = new System.Drawing.Point(46, 157);
            this.Grade.Name = "Grade";
            this.Grade.Size = new System.Drawing.Size(99, 20);
            this.Grade.TabIndex = 39;
            this.Grade.Text = "Grade Level:";
            // 
            // OG
            // 
            this.OG.AutoSize = true;
            this.OG.Location = new System.Drawing.Point(46, 195);
            this.OG.Name = "OG";
            this.OG.Size = new System.Drawing.Size(139, 20);
            this.OG.TabIndex = 5;
            this.OG.Text = "Original Password:";
            this.OG.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 277);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Confirm Password:";
            // 
            // Original
            // 
            this.Original.Location = new System.Drawing.Point(194, 192);
            this.Original.Name = "Original";
            this.Original.Size = new System.Drawing.Size(266, 26);
            this.Original.TabIndex = 0;
            // 
            // Confirm
            // 
            this.Confirm.Location = new System.Drawing.Point(194, 277);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(266, 26);
            this.Confirm.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(156, 321);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 31);
            this.button1.TabIndex = 4;
            this.button1.Text = "Change Password";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(354, 326);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 10;
            // 
            // Nam
            // 
            this.Nam.AutoSize = true;
            this.Nam.Location = new System.Drawing.Point(46, 59);
            this.Nam.Name = "Nam";
            this.Nam.Size = new System.Drawing.Size(55, 20);
            this.Nam.TabIndex = 15;
            this.Nam.Text = "Name:";
            // 
            // Change
            // 
            this.Change.Location = new System.Drawing.Point(194, 233);
            this.Change.Name = "Change";
            this.Change.Size = new System.Drawing.Size(266, 26);
            this.Change.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 236);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Change Password:";
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 365);
            this.Controls.Add(this.Change);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Nam);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.Original);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.OG);
            this.Controls.Add(this.Grade);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.Identity);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Settings";
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.Settings_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Identity;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label Grade;
        private System.Windows.Forms.Label OG;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Original;
        private System.Windows.Forms.TextBox Confirm;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Nam;
        private System.Windows.Forms.TextBox Change;
        private System.Windows.Forms.Label label3;
    }
}