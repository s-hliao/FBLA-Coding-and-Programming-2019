﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop;
using Microsoft.Office.Interop.Outlook;
using Microsoft.Office.Interop.Access;
using Microsoft.Office.Interop.Excel;

namespace FBLA {
    public partial class AdminHome : Form { //administrator home usage
        public Account acc;
        public IOMain main;

        public AdminHome(Account a, IOMain MainSys) {
            this.acc = a;
            this.main = MainSys;
            InitializeComponent();
        }

        private void AdminHome_Load(object sender, EventArgs e) {
            WelcomeLabel.Text = "Welcome, " + acc.firstName + " " + acc.lastName;
        }

        private void AdminHome_FormClosing(object sender, FormClosingEventArgs e) {
            main.Close();
        }

        private void button1_Click(object sender, EventArgs e) {
            main.Show();
            this.Close(); //show the login screen again

        }

        private void button1_Click_1(object sender, EventArgs e) {
            BookCheck check = new BookCheck(acc);
            check.Show(); // create viewing checked books dialog
        }

        private void button4_Click(object sender, EventArgs e) {
            Settings changeSettings = new Settings(acc);
            changeSettings.Show(); // create settings dialog
        }

        private void button7_Click(object sender, EventArgs e) { // build excel report
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application(); //excel initialization
            excel.DisplayAlerts = false;
            if (excel == null) {
                Error.Text = "Excel is not Installed";
            } else {
                Workbook wb = excel.Workbooks.Add(Type.Missing); //Add workbooks
                foreach (int i in IOMain.FBLALib.accounts.Keys) { //generate sheet for every account

                    Sheets worksheets = wb.Worksheets;
                    var ws = (Worksheet)worksheets.Add(Type.Missing, worksheets[1], Type.Missing, Type.Missing);
                    ws.Name = IOMain.FBLALib.accounts[i].firstName + " " + IOMain.FBLALib.accounts[i].lastName + "  -" + IOMain.FBLALib.accounts[i].studentID; // name each sheet for account name and ID

                    ws.Cells[1, 1] = IOMain.FBLALib.accounts[i].firstName;
                    ws.Cells[1, 2] = IOMain.FBLALib.accounts[i].lastName;
                    if (IOMain.FBLALib.accounts[i].isAdmin) {
                        ws.Cells[1, 3] = "Admin";
                    } else if (IOMain.FBLALib.accounts[i].grade == 0) {
                        ws.Cells[1, 3] = "Grade: K";
                    } else {
                        ws.Cells[1, 3] = "Grade: "+IOMain.FBLALib.accounts[i].grade;
                    }
                    ws.Cells[1, 4] = "ID: "+IOMain.FBLALib.accounts[i].studentID; //Account data
                    ws.Cells[2, 1] = "Books";
                    ws.Cells[3, 1] = "Title";
                    ws.Cells[3, 2] = "Author";
                    ws.Cells[3, 3] = "ISBN";
                    ws.Cells[3, 4] = "Date";
                    ws.Cells[3, 5] = "Accession #";
                    int count = 4; //title categories
                    foreach (Book b in IOMain.FBLALib.accounts[i].checkedBooks.Keys) {
                        ws.Cells[count, 1] = b.title;
                        ws.Cells[count, 2] = b.author;
                        ws.Cells[count, 3] = b.ID;
                        ws.Cells[count, 4] = IOMain.FBLALib.accounts[i].checkedBooks[b];
                        ws.Cells[count, 5] = IOMain.FBLALib.accounts[i].index[b];
                        count++;
                    } //load account data
                    count = 2;
                    ws.Cells[1, 6] = "Used Accession #";
                    foreach (int x in IOMain.FBLALib.accounts[i].usedIDs) {
                        ws.Cells[count, 6] = x;
                        count++;
                    } //list Accssion Numbers used
                    Range ran = ws.UsedRange;
                    ran.Columns.AutoFit();

                }
                excel.Visible = true;
            }
            
        }

        private void button6_Click(object sender, EventArgs e) {
            Message message = new Message();
            message.Show(); //create message dialog
        }

        private void button3_Click(object sender, EventArgs e) {
            ManageBooks manage = new ManageBooks();
            manage.Show(); //create Book managing dialog
        }

        private void button2_Click(object sender, EventArgs e) {
            CheckOut checkout = new CheckOut(acc);
            checkout.Show(); //create book Checkout dialog
        }

        private void button5_Click(object sender, EventArgs e) {
            ManageStudent student = new ManageStudent();
            student.Show(); //create student management dialog
        }

        private void Help_Click(object sender, EventArgs e) {
            Help helpWindow = new Help(); //open up help window
            helpWindow.Show();
        }

        private void button8_Click(object sender, EventArgs e) {
            Reset reset = new Reset(main, this);
            reset.Show();
        }
    }
}
