﻿namespace FBLA {
    partial class NewAccount {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.accnt = new System.Windows.Forms.Label();
            this.last = new System.Windows.Forms.Label();
            this.first = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LastName = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.ID = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.adminBox = new System.Windows.Forms.TextBox();
            this.Error = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.TextBox();
            this.Confirm = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.GradeList = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // accnt
            // 
            this.accnt.AutoSize = true;
            this.accnt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.accnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.accnt.Location = new System.Drawing.Point(210, 9);
            this.accnt.Name = "accnt";
            this.accnt.Size = new System.Drawing.Size(201, 25);
            this.accnt.TabIndex = 0;
            this.accnt.Text = "Make A New Account";
            // 
            // last
            // 
            this.last.AutoSize = true;
            this.last.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.last.Location = new System.Drawing.Point(50, 91);
            this.last.Name = "last";
            this.last.Size = new System.Drawing.Size(90, 20);
            this.last.TabIndex = 1;
            this.last.Text = "Last Name:";
            // 
            // first
            // 
            this.first.AutoSize = true;
            this.first.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.first.Location = new System.Drawing.Point(50, 59);
            this.first.Name = "first";
            this.first.Size = new System.Drawing.Size(90, 20);
            this.first.TabIndex = 2;
            this.first.Text = "First Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(181, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "ID:";
            // 
            // LastName
            // 
            this.LastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.LastName.Location = new System.Drawing.Point(171, 88);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(365, 26);
            this.LastName.TabIndex = 1;
            // 
            // FirstName
            // 
            this.FirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.FirstName.Location = new System.Drawing.Point(171, 56);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(365, 26);
            this.FirstName.TabIndex = 0;
            // 
            // ID
            // 
            this.ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ID.ForeColor = System.Drawing.Color.Black;
            this.ID.Location = new System.Drawing.Point(217, 127);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(103, 26);
            this.ID.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(54, 253);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(199, 38);
            this.button1.TabIndex = 8;
            this.button1.Text = "Create Account";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.checkBox1.Location = new System.Drawing.Point(92, 130);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(73, 24);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.Text = "Admin";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(326, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Admin Key:";
            // 
            // adminBox
            // 
            this.adminBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.adminBox.ForeColor = System.Drawing.Color.Black;
            this.adminBox.Location = new System.Drawing.Point(420, 127);
            this.adminBox.Name = "adminBox";
            this.adminBox.Size = new System.Drawing.Size(100, 26);
            this.adminBox.TabIndex = 3;
            // 
            // Error
            // 
            this.Error.AutoSize = true;
            this.Error.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F);
            this.Error.ForeColor = System.Drawing.Color.Red;
            this.Error.Location = new System.Drawing.Point(277, 264);
            this.Error.Name = "Error";
            this.Error.Size = new System.Drawing.Size(0, 17);
            this.Error.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(352, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Grade: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(58, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Password:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // Password
            // 
            this.Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Password.Location = new System.Drawing.Point(201, 171);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(335, 26);
            this.Password.TabIndex = 4;
            // 
            // Confirm
            // 
            this.Confirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Confirm.Location = new System.Drawing.Point(201, 203);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(335, 26);
            this.Confirm.TabIndex = 5;
            this.Confirm.TextChanged += new System.EventHandler(this.Confirm_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(58, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "Confirm Password:";
            // 
            // GradeList
            // 
            this.GradeList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.GradeList.FormattingEnabled = true;
            this.GradeList.Items.AddRange(new object[] {
            "K",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.GradeList.Location = new System.Drawing.Point(414, 126);
            this.GradeList.Name = "GradeList";
            this.GradeList.Size = new System.Drawing.Size(45, 28);
            this.GradeList.TabIndex = 20;
            this.GradeList.Text = "1";
            this.GradeList.SelectedIndexChanged += new System.EventHandler(this.GradeList_SelectedIndexChanged);
            // 
            // NewAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 315);
            this.Controls.Add(this.GradeList);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Error);
            this.Controls.Add(this.adminBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.first);
            this.Controls.Add(this.last);
            this.Controls.Add(this.accnt);
            this.Name = "NewAccount";
            this.Text = "NewAccount";
            this.Load += new System.EventHandler(this.NewAccount_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label accnt;
        private System.Windows.Forms.Label last;
        private System.Windows.Forms.Label first;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox ID;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox adminBox;
        private System.Windows.Forms.Label Error;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.TextBox Confirm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox GradeList;
    }
}