﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBLA {
 
    [Serializable]
    public class LibrarySys{ //main class of entire project, stores all data
        public Dictionary<int, Account> accounts; //account ID mapping to account
        public Dictionary<Book, int[]> bookShelf; //book mapping to number of book copies
        public Dictionary<long, Book> index; //Accession numbers to book
        public bool[] used; //all used accession numbers
        public string adminKey; // current admin Key


        public LibrarySys() {
            this.accounts = new Dictionary<int, Account>();
            this.bookShelf = new Dictionary<Book, int[]>();
            this.index = new Dictionary<long, Book>();
            used = new bool[(long)Math.Pow(2, 20) - 1];
        }

        public bool addAccount(string lastName, string firstName,int grade, string password, int studentID, string dateCreated, bool isAdmin) {
            try {
                accounts[studentID] = new Account(lastName, firstName, grade, password, studentID, dateCreated, isAdmin);
                return true;
            } catch (Exception e) {
                return false;
            }
        } // add account of arguments to data

        public bool addBook(long ID, string title, string author, int copies, int totalCopies, bool IndexUsed, long[]indexes) {
            if (index == null) {
                this.index = new Dictionary<long, Book>();
            }
            try {
                Book addedBook = new Book(ID, title, author, IndexUsed);
                bookShelf[addedBook] = new int[] { copies, totalCopies };
                addCopies(addedBook, ID, totalCopies, indexes); //add in copies
                return true;
            } catch (Exception e) {
                return false;
            }
        } //add books of arguments to data

        public bool addCopies(Book b, long ID, int x, long[]indexes) {
                int curCopies = bookShelf[b][0];
                int totalCopies = bookShelf[b][1];
                bookShelf[b] = new int[] { curCopies+x, totalCopies+x}; // add the number copies
            for(int i = 0; i<x; i++) {
                index.Add(indexes[i], b); // add in accession numbers to index list
            }
            return false;
        }  // add the number of copies with books like this

        public void setAdminKey(string s) {
            adminKey = s;
        }

   
    }
}
