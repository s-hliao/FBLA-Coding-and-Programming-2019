﻿namespace FBLA {
    partial class StudentSettings {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.newPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Nam = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PasswordChange = new System.Windows.Forms.Button();
            this.Confirm = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.Label();
            this.Grade = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.GradeButton = new System.Windows.Forms.Button();
            this.changeGrade = new System.Windows.Forms.Label();
            this.GradeList = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.IDButton = new System.Windows.Forms.Button();
            this.ChangeID = new System.Windows.Forms.TextBox();
            this.s = new System.Windows.Forms.Label();
            this.t = new System.Windows.Forms.Label();
            this.First = new System.Windows.Forms.TextBox();
            this.Last = new System.Windows.Forms.TextBox();
            this.NameChange = new System.Windows.Forms.Button();
            this.NameError = new System.Windows.Forms.Label();
            this.IDError = new System.Windows.Forms.Label();
            this.PasswordError = new System.Windows.Forms.Label();
            this.Error = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newPassword
            // 
            this.newPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.newPassword.Location = new System.Drawing.Point(180, 570);
            this.newPassword.Name = "newPassword";
            this.newPassword.Size = new System.Drawing.Size(266, 26);
            this.newPassword.TabIndex = 6;
            this.newPassword.TextChanged += new System.EventHandler(this.Change_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(32, 570);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Change Password:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Nam
            // 
            this.Nam.AutoSize = true;
            this.Nam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Nam.Location = new System.Drawing.Point(25, 61);
            this.Nam.Name = "Nam";
            this.Nam.Size = new System.Drawing.Size(55, 20);
            this.Nam.TabIndex = 24;
            this.Nam.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(333, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 23;
            // 
            // PasswordChange
            // 
            this.PasswordChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.PasswordChange.Location = new System.Drawing.Point(75, 650);
            this.PasswordChange.Name = "PasswordChange";
            this.PasswordChange.Size = new System.Drawing.Size(164, 31);
            this.PasswordChange.TabIndex = 8;
            this.PasswordChange.Text = "Change Password";
            this.PasswordChange.UseVisualStyleBackColor = true;
            this.PasswordChange.Click += new System.EventHandler(this.button1_Click);
            // 
            // Confirm
            // 
            this.Confirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Confirm.Location = new System.Drawing.Point(179, 608);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(266, 26);
            this.Confirm.TabIndex = 7;
            this.Confirm.TextChanged += new System.EventHandler(this.Confirm_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(32, 611);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Confirm Password:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Password.Location = new System.Drawing.Point(32, 532);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(139, 20);
            this.Password.TabIndex = 18;
            this.Password.Text = "Original Password:";
            this.Password.Click += new System.EventHandler(this.OG_Click);
            // 
            // Grade
            // 
            this.Grade.AutoSize = true;
            this.Grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Grade.Location = new System.Drawing.Point(35, 398);
            this.Grade.Name = "Grade";
            this.Grade.Size = new System.Drawing.Size(99, 20);
            this.Grade.TabIndex = 17;
            this.Grade.Text = "Grade Level:";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Date.Location = new System.Drawing.Point(37, 360);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(109, 20);
            this.Date.TabIndex = 16;
            this.Date.Text = "Date Created:";
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ID.Location = new System.Drawing.Point(37, 223);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(30, 20);
            this.ID.TabIndex = 15;
            this.ID.Text = "ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(166, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Account Settings";
            // 
            // GradeButton
            // 
            this.GradeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.GradeButton.Location = new System.Drawing.Point(75, 473);
            this.GradeButton.Name = "GradeButton";
            this.GradeButton.Size = new System.Drawing.Size(164, 31);
            this.GradeButton.TabIndex = 5;
            this.GradeButton.Text = "Change Grade";
            this.GradeButton.UseVisualStyleBackColor = true;
            this.GradeButton.Click += new System.EventHandler(this.GradeButton_Click);
            // 
            // changeGrade
            // 
            this.changeGrade.AutoSize = true;
            this.changeGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.changeGrade.Location = new System.Drawing.Point(35, 432);
            this.changeGrade.Name = "changeGrade";
            this.changeGrade.Size = new System.Drawing.Size(134, 20);
            this.changeGrade.TabIndex = 28;
            this.changeGrade.Text = "New Grade Level:";
            // 
            // GradeList
            // 
            this.GradeList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.GradeList.FormattingEnabled = true;
            this.GradeList.Items.AddRange(new object[] {
            "K",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.GradeList.Location = new System.Drawing.Point(180, 429);
            this.GradeList.Name = "GradeList";
            this.GradeList.Size = new System.Drawing.Size(121, 28);
            this.GradeList.TabIndex = 100;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(35, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 20);
            this.label5.TabIndex = 31;
            this.label5.Text = "New ID:";
            // 
            // IDButton
            // 
            this.IDButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.IDButton.Location = new System.Drawing.Point(75, 300);
            this.IDButton.Name = "IDButton";
            this.IDButton.Size = new System.Drawing.Size(164, 31);
            this.IDButton.TabIndex = 4;
            this.IDButton.Text = "Change ID";
            this.IDButton.UseVisualStyleBackColor = true;
            this.IDButton.Click += new System.EventHandler(this.IDButton_Click);
            // 
            // ChangeID
            // 
            this.ChangeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ChangeID.Location = new System.Drawing.Point(106, 254);
            this.ChangeID.Name = "ChangeID";
            this.ChangeID.Size = new System.Drawing.Size(115, 26);
            this.ChangeID.TabIndex = 3;
            this.ChangeID.TextChanged += new System.EventHandler(this.ChangeID_TextChanged);
            // 
            // s
            // 
            this.s.AutoSize = true;
            this.s.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.s.Location = new System.Drawing.Point(25, 102);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(150, 20);
            this.s.TabIndex = 34;
            this.s.Text = "Change First Name:";
            // 
            // t
            // 
            this.t.AutoSize = true;
            this.t.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.t.Location = new System.Drawing.Point(25, 139);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(150, 20);
            this.t.TabIndex = 33;
            this.t.Text = "Change Last Name:";
            // 
            // First
            // 
            this.First.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.First.Location = new System.Drawing.Point(180, 102);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(266, 26);
            this.First.TabIndex = 0;
            this.First.TextChanged += new System.EventHandler(this.First_TextChanged);
            // 
            // Last
            // 
            this.Last.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Last.Location = new System.Drawing.Point(180, 134);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(266, 26);
            this.Last.TabIndex = 1;
            this.Last.TextChanged += new System.EventHandler(this.Last_TextChanged);
            // 
            // NameChange
            // 
            this.NameChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.NameChange.Location = new System.Drawing.Point(75, 176);
            this.NameChange.Name = "NameChange";
            this.NameChange.Size = new System.Drawing.Size(164, 31);
            this.NameChange.TabIndex = 2;
            this.NameChange.Text = "Change Name";
            this.NameChange.UseVisualStyleBackColor = true;
            this.NameChange.Click += new System.EventHandler(this.NameChange_Click);
            // 
            // NameError
            // 
            this.NameError.AutoSize = true;
            this.NameError.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.NameError.ForeColor = System.Drawing.Color.Red;
            this.NameError.Location = new System.Drawing.Point(301, 181);
            this.NameError.Name = "NameError";
            this.NameError.Size = new System.Drawing.Size(0, 20);
            this.NameError.TabIndex = 38;
            // 
            // IDError
            // 
            this.IDError.AutoSize = true;
            this.IDError.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.IDError.ForeColor = System.Drawing.Color.Red;
            this.IDError.Location = new System.Drawing.Point(273, 305);
            this.IDError.Name = "IDError";
            this.IDError.Size = new System.Drawing.Size(0, 20);
            this.IDError.TabIndex = 39;
            // 
            // PasswordError
            // 
            this.PasswordError.AutoSize = true;
            this.PasswordError.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.PasswordError.ForeColor = System.Drawing.Color.Red;
            this.PasswordError.Location = new System.Drawing.Point(273, 655);
            this.PasswordError.Name = "PasswordError";
            this.PasswordError.Size = new System.Drawing.Size(0, 20);
            this.PasswordError.TabIndex = 40;
            // 
            // Error
            // 
            this.Error.AutoSize = true;
            this.Error.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Error.ForeColor = System.Drawing.Color.Red;
            this.Error.Location = new System.Drawing.Point(333, 432);
            this.Error.Name = "Error";
            this.Error.Size = new System.Drawing.Size(0, 20);
            this.Error.TabIndex = 41;
            // 
            // StudentSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(506, 693);
            this.Controls.Add(this.Error);
            this.Controls.Add(this.PasswordError);
            this.Controls.Add(this.IDError);
            this.Controls.Add(this.NameError);
            this.Controls.Add(this.NameChange);
            this.Controls.Add(this.First);
            this.Controls.Add(this.Last);
            this.Controls.Add(this.s);
            this.Controls.Add(this.t);
            this.Controls.Add(this.ChangeID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.IDButton);
            this.Controls.Add(this.GradeList);
            this.Controls.Add(this.changeGrade);
            this.Controls.Add(this.GradeButton);
            this.Controls.Add(this.newPassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Nam);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PasswordChange);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Grade);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.label1);
            this.Name = "StudentSettings";
            this.Text = "StudentSettings";
            this.Load += new System.EventHandler(this.StudentSettings_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox newPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Nam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button PasswordChange;
        private System.Windows.Forms.TextBox Confirm;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Label Grade;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button GradeButton;
        private System.Windows.Forms.Label changeGrade;
        private System.Windows.Forms.ComboBox GradeList;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button IDButton;
        private System.Windows.Forms.TextBox ChangeID;
        private System.Windows.Forms.Label s;
        private System.Windows.Forms.Label t;
        private System.Windows.Forms.TextBox First;
        private System.Windows.Forms.TextBox Last;
        private System.Windows.Forms.Button NameChange;
        private System.Windows.Forms.Label NameError;
        private System.Windows.Forms.Label IDError;
        private System.Windows.Forms.Label PasswordError;
        private System.Windows.Forms.Label Error;
    }
}