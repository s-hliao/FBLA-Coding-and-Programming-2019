﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBLA
{

    [Serializable]
    public class Account // used for accounts in LibrarySys
    {
        public string lastName;
        public string firstName;
        public string password;
        public int studentID; // unique ID
        public Dictionary<Book, string> checkedBooks;//all owned books
        public Dictionary<Book, int> index; // accession numbers of currently owned books
        public string dateCreated; //date account was created in mm/dd/yyyy
        public int grade;
        public bool isAdmin; //administrator or student
        public HashSet<long> usedIDs; //all Accession numbers used by account
        public Account(string lastName, string firstName, int grade, string password, int studentID, string dateCreated, bool isAdmin)
        {
            this.lastName = lastName;
            this.firstName = firstName;
            this.studentID = studentID;
            this.grade = grade;
            this.checkedBooks = new Dictionary<Book, string>();
            this.index = new Dictionary<Book, int>();
            this.dateCreated = dateCreated;
            this. password = password;
            this.isAdmin = isAdmin;
            usedIDs = new HashSet<long>();// initialize
        }

        public override bool Equals(Object o)
        {
            Account item = o as Account;

            if (item == null) {
                return false;
            }

            return this.studentID==item.studentID;
        } //Overwrite equa;s

        public override int GetHashCode()
        {
            return studentID;
        } //Overwrite HashCode
    }
}
