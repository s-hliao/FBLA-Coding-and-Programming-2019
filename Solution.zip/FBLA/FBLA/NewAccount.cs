﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class NewAccount : Form { //form for creating a new account
        public static bool makeAdmin;

        public NewAccount() {
            InitializeComponent();
        }

        private void NewAccount_Load(object sender, EventArgs e) {
            makeAdmin = false;
            label2.Hide();
            adminBox.Hide();
            label1.Show();
            ID.Show();
            label3.Show();
            GradeList.Show();
            if(IOMain.FBLALib.adminKey=="") Error.Text = "Set Up Admin Key"; // if admin key is not present, first set that up
            ID.MaxLength = 8;
            Password.PasswordChar = '*';
            Confirm.PasswordChar = '*';
            adminBox.PasswordChar = '*';
            this.AcceptButton = button1;
        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) {
            if (makeAdmin) {
                makeAdmin = false;
                label2.Hide();
                adminBox.Hide();
                label3.Show();
                GradeList.Show();
            } else {
                makeAdmin = true;
                label2.Show();
                adminBox.Show();
                label3.Hide();
                GradeList.Hide();
            } //toggle asking for Grade or Adminkey based on if Admin is selected
        }

        private void button1_Click(object sender, EventArgs e) {
            bool correct = false;
            bool grade = false;
            try {
                Int32.Parse(ID.Text);
                correct = true;
            } catch {
                Error.Text = "ID must be a valid number";
            }

            try {
                if (GradeList.Text != "K") { 
                    Int32.Parse(GradeList.Text);
                }
                grade = true;
            } catch {
                Error.Text = "Grade must be a valid number";
            }
            if (!makeAdmin && correct && grade) {
                if (IOMain.FBLALib.accounts.ContainsKey(Int32.Parse(ID.Text))) {
                    Error.Text = "ID is already used";
                } else if (FirstName.Text == "" || LastName.Text == "" || ID.Text == "" || Password.Text == "" || Confirm.Text == "") {
                    Error.Text = "All fields must be filled";
                } else if (GradeList.Text != "K" && (Int32.Parse(GradeList.Text) < 1 || Int32.Parse(GradeList.Text) > 16)) {
                    Error.Text = "This must be a valid grade";
                } else if (Password.Text != Confirm.Text) {
                    Error.Text = "Passwords do not match";
                } else if (Password.Text.Length <=5) {
                    Error.Text = "Passwords do must be greater than 5 characters";
                } else if (GradeList.Text == "K") { // if Kindergardener
                    IOMain.FBLALib.addAccount(LastName.Text, FirstName.Text, 0, Password.Text, Int32.Parse(ID.Text), DateTime.Today.ToString("MM/dd/yyyy"), false); // add student account to library system list
                    Confirmed ConfirmedForm = new Confirmed(LastName.Text, FirstName.Text, Int32.Parse(ID.Text), Int32.Parse(GradeList.Text), false, DateTime.Today.ToString("MM/dd/yyyy")); // create confirmed window with entered data
                    ConfirmedForm.Show();
                    LastName.Text = "";
                    FirstName.Text = "";
                    Password.Text = "";
                    GradeList.Text = "";
                    ID.Text = "";
                    Confirm.Text = ""; // reset
                    Error.Text = "";
                    IOMain.overwrite(); // overwrite date
                } else { // if student
                    IOMain.FBLALib.addAccount(LastName.Text, FirstName.Text, Int32.Parse(GradeList.Text), Password.Text, Int32.Parse(ID.Text), DateTime.Today.ToString("MM/dd/yyyy"), false); // add student account to library system list
                    Confirmed ConfirmedForm = new Confirmed(LastName.Text, FirstName.Text, Int32.Parse(ID.Text), Int32.Parse(GradeList.Text), false, DateTime.Today.ToString("MM/dd/yyyy")); // create confirmed window with entered data
                    ConfirmedForm.Show();
                    LastName.Text = "";
                    FirstName.Text = "";
                    Password.Text = "";
                    ID.Text = "";
                    GradeList.Text = "";
                    Confirm.Text = ""; //reset
                    Error.Text = "";
                    IOMain.overwrite(); // overwrite data
                }
            } else if (Password.Text.Length < 5) {
                Error.Text = "Passwords must be greater than 5 characters";
            } else if(correct) {
                if (IOMain.FBLALib.accounts.ContainsKey(int.Parse(ID.Text))) {
                    Error.Text = "ID is already used";
                } else if (adminBox.Text != IOMain.FBLALib.adminKey) {
                    Error.Text = "Admin Key is not Correct";
                } else if (adminBox.Text == "" || FirstName.Text == "" || LastName.Text == "" || ID.Text == "" || Password.Text == "" || Confirm.Text == "") {
                    Error.Text = "All Fields  must be Filled";
                } else { //if Admin
                    IOMain.FBLALib.addAccount(LastName.Text, FirstName.Text, -1, Password.Text, Int32.Parse(ID.Text), DateTime.Now.Date.ToString("MM/dd/yyyy"), true);
                    Confirmed ConfirmedForm = new Confirmed(LastName.Text, FirstName.Text, Int32.Parse(ID.Text), -1, true, DateTime.Now.Date.ToString("MM/dd/yyyy"));
                    ConfirmedForm.Show();
                    LastName.Text = "";
                    FirstName.Text = "";
                    Password.Text = "";
                    ID.Text = "";
                    Confirm.Text = "";
                    adminBox.Text = "";
                    Error.Text = "";//reset
                    IOMain.overwrite(); //overwrite Storage 
                }
            }

            if (IOMain.FBLALib.adminKey == ""||IOMain.FBLALib.adminKey == null) Error.Text = "Set Up Admin Key"; //make sure admin key is available
        }

        private void label4_Click(object sender, EventArgs e) {

        }

        private void GradeList_SelectedIndexChanged(object sender, EventArgs e) {

        }

        private void Confirm_TextChanged(object sender, EventArgs e) {

        }
    }
}
