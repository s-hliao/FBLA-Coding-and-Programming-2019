﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Json;

namespace FBLA
{
    public partial class IOMain : Form //main central pivot around which program revolves - all data is written to and stored using this class
    {
        public static LibrarySys FBLALib = new LibrarySys();

        public IOMain(LibrarySys lib) {
            InitializeComponent();
            FBLALib = lib;

        }
        public static void overwrite() {
            LibrarySys lib = FBLALib;
            var path = Application.StartupPath+"\\lib.json";
            var wfile = new System.IO.FileStream(path, System.IO.FileMode.Create); //always create or overwrite
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(LibrarySys));
            ser.WriteObject(wfile, lib);
            wfile.Close(); //serialize FBLALib to json whenever overwrite is called


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loadLabel.Text = "...";
            loadLabel.Text = " ";
            ErrorLabel.Text = "";
            System.Threading.Thread.Sleep(3000);
            PasswordInput.PasswordChar = '*'; //set hidden password
            overwrite(); // check that overwriting data works or create json file
            this.AcceptButton = Login;
        }

        private void Setup_Click(object sender, EventArgs e) {
            AdminKey AdminKeyForm = new AdminKey();
            AdminKeyForm.Show(); // show admin key form
        }

        private void button1_Click(object sender, EventArgs e) {
            NewAccount NewAccountForm = new NewAccount();
            NewAccountForm.Show(); //show new account form
        }

        private void Login_Click(object sender, EventArgs e) { //login
            bool found = false;
            bool error = false;
            int x;
            if (AccInput.Text == "" || Password.Text == "") {
                ErrorLabel.Text = "All fields must be filled";
            } else {

                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    if (!Int32.TryParse(AccInput.Text, out x)) {
                        error = true;
                        ErrorLabel.Text = "ID not valid"; //unreadable

                    } else if (Int32.TryParse(AccInput.Text, out x) && x == i && PasswordInput.Text == IOMain.FBLALib.accounts[i].password) {
                        found = true;
                        AccInput.Text = "";
                        PasswordInput.Text = "";
                        ErrorLabel.Text = "";
                        if (IOMain.FBLALib.accounts[i].isAdmin) {
                            AdminHome main = new AdminHome(IOMain.FBLALib.accounts[i], this);
                            main.Show();
                            this.Hide(); // if login is correct for an admin, construct admin home with an account
                        } else {
                            StudentHome main = new StudentHome(IOMain.FBLALib.accounts[i], this);
                            main.Show();
                            this.Hide(); // if login is correct for studnet, construct student home with an account
                        }
                        break;
                        
                    } else if (Int32.TryParse(AccInput.Text, out x) && x == i) {
                        error = true;
                        ErrorLabel.Text = "Wrong Password";
                        break;
                    }
                }
                if (!found && !error) {
                    ErrorLabel.Text = "No Such ID";
                }
            }
        }
    }
}
