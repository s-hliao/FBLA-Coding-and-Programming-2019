﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop;
using Microsoft.Office.Interop.Outlook;
using Microsoft.Office.Interop.Access;

namespace FBLA {
    public partial class Message : Form { // create a formatted outlook message

        public Message() {
            InitializeComponent();
        }

        private void Message_Load(object sender, EventArgs e) {
            this.AcceptButton = button1;


        }

        private void CreateMailItem(string message) { //function to create mail
            Microsoft.Office.Interop.Outlook.Application application = new Microsoft.Office.Interop.Outlook.Application(); //open up outlook
            MailItem mailItem = application.CreateItem(OlItemType.olMailItem);
            mailItem.Subject = Subject.Text;
            mailItem.To = Mail.Text;
            mailItem.Body = message; // outlook message
            mailItem.Importance = OlImportance.olImportanceNormal; //set importance of message
            mailItem.Display(false); // display outlook
        }

        private void button1_Click(object sender, EventArgs e) {
            Book b = null;
            bool found = false;
            int n = 0;
            int index = 0;
            string message;
            
            
             if (Request.Text == "Check Out") {
                    if (IOMain.FBLALib.index != null && IOMain.FBLALib.index.Keys != null) {
                        foreach (int x in IOMain.FBLALib.index.Keys) {
                            if (Int32.TryParse(ID.Text, out n)) {
                                if (n == x) {
                                    b = IOMain.FBLALib.index[x];
                                    index = n;
                                    found = true;
                                } // search for book in system

                            }
                        }
                        if (found) {
                            message = "This is a message from the Ebook System\n\n";
                            message = message + "You are requested to check out " + b.title + " by " + b.author + " using accession number " + index+".";
                            message = message + " " + Notes.Text; //write out email for request using book's title, author, and accession number
                            CreateMailItem(message); // put message in mail
                            Subject.Text = "";
                            Mail.Text = "";
                            ID.Text = "";
                            Notes.Text = "";
                        Error.Text = "";
                    } else {
                            Error.Text = "Book ID does not exist";
                        }
                    }else {
                        Error.Text = "Invalid index";
                    }
                } else {
                    if (IOMain.FBLALib.accounts.Keys != null) {
                        foreach (int x in IOMain.FBLALib.accounts.Keys) {
                            if (Int32.TryParse(ID.Text, out n)) {
                                if (IOMain.FBLALib.accounts[x].index.Keys!=null) {
                                    foreach(Book bk in IOMain.FBLALib.accounts[x].index.Keys){
                                        if (n == IOMain.FBLALib.accounts[x].index[bk]) {
                                            b = bk;
                                            index = IOMain.FBLALib.accounts[x].index[bk];
                                            found = true;
                                            break;
                                            //searh in accounts for the accession number
                                        }
                                    }

                                }

                            }
                        }
                        if (found) {
                            message = "This is a message from the Ebook System\n\n";
                            message = message + "You are requested to return " + b.title+" by "+b.author + " using accession number " + index+".";
                            message = message + " " + Notes.Text; //create message using accession number, book author, and title
                            CreateMailItem(message); // put message in mail
                            Subject.Text = "";
                            Mail.Text = "";
                            ID.Text = "";
                            Notes.Text = "";
                            Request.Text = "";
                            Error.Text = "";
                        } else {
                            Error.Text = "Book ID does not exist";
                        
                        }
                    } else {
                        Error.Text = "Invalid index";
                    }
                }
                
            }

        private void Request_SelectedIndexChanged(object sender, EventArgs e) {

        }
    }
    }
