﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class CheckOut : Form { //check out a book
        Account acc;
        public CheckOut(Account a) {
            InitializeComponent();
            this.acc = a;
            this.AcceptButton = button1;
        }

        private void button1_Click(object sender, EventArgs e) {
            int x;
            bool found = false;
            Book b = null;
            if (Int32.TryParse(ID.Text, out x)) { // check out book
                if (IOMain.FBLALib.index.ContainsKey(x)) {
                    b = IOMain.FBLALib.index[x];
                    if (IOMain.FBLALib.bookShelf[b][0]==0) { // make sure that input is all valid
                        Error.Text = "No Available Books";
                    } else if (!acc.checkedBooks.ContainsKey(b)) {
                        foreach (int i in IOMain.FBLALib.accounts.Keys) {
                            if (i == acc.studentID) { // find account and make sure the book is not already contained
                                IOMain.FBLALib.accounts[i].checkedBooks.Add(b, DateTime.Now.ToString("MM/dd/yyyy")); //add books to account
                                IOMain.FBLALib.accounts[i].index[b]= x; //add accession number to account's dictionary
                                IOMain.FBLALib.accounts[i].usedIDs.Add(x);  //add accession number to used numbers
                                IOMain.FBLALib.used[x] = true; //mark accession number used
                                IOMain.FBLALib.index.Remove(x); //remove book from index of the Library


                                int copies = IOMain.FBLALib.bookShelf[b][0];
                                int total = IOMain.FBLALib.bookShelf[b][1];
                                copies -= 1;
                                IOMain.FBLALib.bookShelf[b]=new int[] { copies, total }; // total copies have decreased


                                Error.Text = "Checkout successful";
                                ID.Text = "";
                                found = true;
                                IOMain.overwrite();
                                
                                break;
                            } 
                        }
                    } else {
                        Error.Text = "You already have this book";
                    }
                } else {
                    Error.Text = "ID Unavailable";
                }
            } else {
                Error.Text = "Invalid ID";
            }
            
        }

        private void CheckOutcs_Load(object sender, EventArgs e) {
            Error.Text = "";
            ID.MaxLength = 10;
        }

        private void ID_TextChanged(object sender, EventArgs e) {

        }
    }
}
