﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class ManageStudent : Form {
        string searchString;
        public ManageStudent() {
            InitializeComponent();
        }

        private void ManageStudent_Load(object sender, EventArgs e) {
            searchString = "";
            update();
            
        }

        private void button1_Click(object sender, EventArgs e) {
            long x = 0;
            if (long.TryParse(ID.Text, out x)) {
                bool found = false;
                Account acc = null;
                foreach(int i in IOMain.FBLALib.accounts.Keys) {
                    if (IOMain.FBLALib.accounts[i].studentID == x) {
                        acc = IOMain.FBLALib.accounts[i];
                        found = true;
                        break; // search for the account by ID
                    }
                    
                }
                if (found) {
                    BookCheck studentText = new BookCheck(acc);
                    studentText.Show();  //show checked out books for given account
                    Error.Text = "";
                } else {
                    Error.Text = "No Such ID";
                }
            } else{
                Error.Text = "Invalid ID";
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            long x = 0;
            if (long.TryParse(ID.Text, out x)) {
                bool found = false;
                Account acc = null;
                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    if (i == x) {
                        acc = IOMain.FBLALib.accounts[i];
                        found = true;
                        break;// search for the account by ID
                    }
                }
                if (found) {
                    StudentSettings studentText = new StudentSettings(acc, this); //open full setting changes for account
                    studentText.Show();
                    Error.Text = "";
                } else {
                    Error.Text = "No Such ID";
                }
            } else {
                Error.Text = "Invalid ID";
            }
        }

        private void button3_Click(object sender, EventArgs e) {
            update();
        }

        private void loadIn(int i) {
                if (!IOMain.FBLALib.accounts[i].isAdmin) {
                    if (IOMain.FBLALib.accounts[i].grade == 0) {
                        string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, "K", IOMain.FBLALib.accounts[i].dateCreated };
                        var listViewItem = new ListViewItem(display);
                        listView1.Items.Add(listViewItem);
                        //add kindergardeners to listview
                    } else {
                        string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, IOMain.FBLALib.accounts[i].grade.ToString(), IOMain.FBLALib.accounts[i].dateCreated };
                        var listViewItem = new ListViewItem(display);
                        listView1.Items.Add(listViewItem);
                        //add students to listview
                    }
                } else {
                    string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, "Admin", IOMain.FBLALib.accounts[i].dateCreated };
                    var listViewItem = new ListViewItem(display);
                    listView1.Items.Add(listViewItem);
                    //add admin to listview
                }
        }

        public void update() {
            listView1.Items.Clear();
            if (searchString == "") {
                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    loadIn(i);
                }
            } else if (searchString == "Name") {
                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    if((IOMain.FBLALib.accounts[i].firstName+" "+ IOMain.FBLALib.accounts[i].lastName).Contains(searchBox.Text)){
                        loadIn(i);
                    }
                }
            } else if (searchString == "ID") {
                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    if (IOMain.FBLALib.accounts[i].studentID.ToString().Contains(searchBox.Text)) {
                        loadIn(i);
                    }

                }

            } else if(searchString == "Grade") {
                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    if (IOMain.FBLALib.accounts[i].grade.ToString().Contains(searchBox.Text)) {
                        loadIn(i);
                    }

                }
            } else {
                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    if (IOMain.FBLALib.accounts[i].dateCreated.Contains(searchBox.Text)) {
                        loadIn(i);
                    }

                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e) {

        }

        private void Selector_SelectedIndexChanged(object sender, EventArgs e) {
            this.AcceptButton = button3;
        }

        private void button3_Click_1(object sender, EventArgs e) {
            if (Selector.Text =="") {
                Error.Text = "No Selection Type";
            } else {
                searchString = Selector.Text;
                update();
                Error.Text = "";
            }
        }

        private void button4_Click(object sender, EventArgs e) {
            searchString = "";
            Selector.Text = "";
            searchBox.Text = "";
        }

        private void searchBox_TextChanged(object sender, EventArgs e) {
            this.AcceptButton = button3;
        }

        private void ID_TextChanged(object sender, EventArgs e) {
            this.AcceptButton = button1;
        }
    }
}
