﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class StudentSettings : Form {
        Account acc;
        ManageStudent student;
        public StudentSettings(Account a, ManageStudent student) {
            InitializeComponent();
            this.acc = a;
            this.student = student;
        }

        private void Change_TextChanged(object sender, EventArgs e) {
            AcceptButton = PasswordChange;
        }

        private void label3_Click(object sender, EventArgs e) {

        }

        private void label6_Click(object sender, EventArgs e) {

        }

        private void button1_Click(object sender, EventArgs e) { // change password
            if (newPassword.Text.Length <= 5) {
                PasswordError.Text = "Password must be >5 characters";
            } else if (Confirm.Text != "" && newPassword.Text != "") {
                if (Confirm.Text == newPassword.Text) {
                    acc.password = newPassword.Text;
                    newPassword.Text = "";
                    Confirm.Text = "";
                    IOMain.FBLALib.accounts[acc.studentID] = acc; // update FBLAsys account
                    PasswordError.Text = "Password Changed";
                    Password.Text = "Original Password: " + acc.password; // change password 
                    IOMain.overwrite(); //overwite storage
                } else {
                    PasswordError.Text = "Passwords do not match";
                }
            }  else {
                PasswordError.Text = "Invalid ID";
            }
        }

        private void Confirm_TextChanged(object sender, EventArgs e) {
            AcceptButton = PasswordChange;
        }

        private void OG_Click(object sender, EventArgs e) {

        }

        private void StudentSettings_Load(object sender, EventArgs e) {
            acc = IOMain.FBLALib.accounts[acc.studentID];
            Nam.Text = acc.firstName + " " + acc.lastName;
            ID.Text = acc.studentID + " ";
            Date.Text = "Date Created: " + acc.dateCreated;
            if (!acc.isAdmin) {
                Grade.Text = "Grade Level: " + acc.grade;
                changeGrade.Show();
                GradeList.Show();
                GradeButton.Hide();
            } else {
                Grade.Text = "Admin";
                changeGrade.Hide();
                GradeList.Show();
                GradeButton.Show();
            }
            Password.Text = "Original Password: " + acc.password; // display account data

            newPassword.PasswordChar = '*';
            Confirm.PasswordChar = '*'; //set hidden password
            ChangeID.MaxLength = 9; //set id max length
        }

        private void IDButton_Click(object sender, EventArgs e) {//change ID
            acc = IOMain.FBLALib.accounts[acc.studentID];
            int x = 0;
            if (int.TryParse(ChangeID.Text, out x)) {
                IOMain.FBLALib.accounts.Remove(acc.studentID); //remove ID from libary system
                acc.studentID = x;
                IDError.Text = "ID Changed";
                ID.Text = acc.studentID + " ";
                IOMain.FBLALib.accounts[acc.studentID] = acc; //update library system
                IOMain.overwrite(); // overwrite data
                ChangeID.Text = "";
                IDError.Text = "Passwrd Changed";

            } else {
                IDError.Text = "Invalid ID";
            }
            student.update();
        }

        private void NameChange_Click(object sender, EventArgs e) { //change name
            acc = IOMain.FBLALib.accounts[acc.studentID];
            if (First.Text=="" && Last.Text==""){
                NameError.Text = "A field must be filled in";
            } else {
                if (First.Text != "") {
                    acc.firstName = First.Text;
                    First.Text = "";
                }
                if(Last.Text != "") {
                    acc.lastName = Last.Text;
                    Last.Text = "";
                }
                //check if lastname or firstnme used
                NameError.Text = "Name Changed";
                IOMain.FBLALib.accounts[acc.studentID]=acc;  // replace account
                IOMain.overwrite(); // overwrite librarysystem data
                Nam.Text = acc.firstName + " " + acc.lastName;
            }
            student.update();
        }

        private void GradeButton_Click(object sender, EventArgs e) { //change grade
            acc = IOMain.FBLALib.accounts[acc.studentID];
            if (GradeList.Text == "") {
                Error.Text = "Select a grade";
            } else {
                if (GradeList.Text != "K") {
                    acc.grade = int.Parse(GradeList.Text);
                    IOMain.FBLALib.accounts[acc.studentID] = acc;//replace account
                    Grade.Text = "Grade Level: " + acc.grade; //display grade
                    IOMain.overwrite(); //overwrite librarysystem storage
                    Error.Text = "";
                } else {
                    acc.grade = 0;
                    IOMain.FBLALib.accounts[acc.studentID] = acc; // replace account
                    Grade.Text = "Grade Level: K"; //display grade
                    IOMain.overwrite(); // overwrite storage
                    Error.Text = "";
                }
            }
            student.update();
        }

        private void First_TextChanged(object sender, EventArgs e) {
            AcceptButton = NameChange;
        }

        private void Last_TextChanged(object sender, EventArgs e) {
            AcceptButton = NameChange;
        }

        private void ChangeID_TextChanged(object sender, EventArgs e) {
            AcceptButton = IDButton;
        }
    }
}
