﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Json;
using System.Diagnostics;

namespace FBLA
{
    static class Program //application inititialization
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            Process[] result = Process.GetProcessesByName("FBLA");
            if (result.Length > 1) {
                result[0].Close();
            } //ensure multiple instances are not running

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var path = Application.StartupPath + "\\lib.json"; //path of json storage file which is continuously updated with serialized data
            LibrarySys libSys = new LibrarySys(); // sample library system
            if (File.Exists(path)) {
                FileStream file = new FileStream(path, FileMode.Open);
                DataContractJsonSerializer ser = new DataContractJsonSerializer(libSys.GetType());
                libSys = ser.ReadObject(file) as LibrarySys; //deserialize json file to object libsys
                file.Close(); 
                Application.Run(new IOMain(libSys));
            } else {
                Application.Run(new IOMain(libSys)); // if the path does not exist, initialize with a blank library system
            }
        }
    }
}
