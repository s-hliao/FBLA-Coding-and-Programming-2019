﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class Reset : Form {
        IOMain main;
        AdminHome home;
        public Reset(IOMain main, AdminHome home) { //erase all memory
            InitializeComponent();
            this.main = main;
            this.home = home;
        }

        private void button1_Click(object sender, EventArgs e) {
            if (keyInput.Text == IOMain.FBLALib.adminKey) {
                IOMain.FBLALib = new LibrarySys();
                home.Close();
                IOMain.overwrite();
                main.Show();
                Error.Text = "Reset Done"; //initialize with new LIbrarysys and overwrite
            }else{
                Error.Text = "Admin Key Incorrect";

            }

            

        }

        private void Reset_Load(object sender, EventArgs e) {
            keyInput.PasswordChar = '*';
        }
    }
}
