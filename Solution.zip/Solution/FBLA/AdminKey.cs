﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class AdminKey : Form { //change the adminsitrator key
        public AdminKey() {
            InitializeComponent();
        }

        private void AdminKey_Load(object sender, EventArgs e) {
            OldKeyInput.PasswordChar = '*';
            newKeyInput.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e) {
            if (newKeyInput.Text.Length <= 3) {
                ConfirmLabel.Text = "New Key must be >3 char in length";
            } else if (IOMain.FBLALib.adminKey == " " || IOMain.FBLALib.adminKey == ""||IOMain.FBLALib.adminKey==null) { // if there is no AdminKey
                IOMain.FBLALib.setAdminKey(newKeyInput.Text);//set new admin Key
                ConfirmLabel.Text = "Key has been changed";
                OldKeyInput.Text = "";
                newKeyInput.Text = "";
                OldAdminConfirm.Text = "";//reset
                IOMain.overwrite(); // overwrite file
            }  else if (IOMain.FBLALib.adminKey == OldKeyInput.Text) { //else if the key already exists, check against old
                IOMain.FBLALib.setAdminKey(newKeyInput.Text); // set new adminKey
                ConfirmLabel.Text = "Key has been changed";
                OldKeyInput.Text = "";
                newKeyInput.Text = "";
                OldAdminConfirm.Text = ""; //reset
                IOMain.overwrite(); // overwrite file
            } else {
                OldAdminConfirm.Text = "Old Key Incorrect";
            }
            
        }

        private void OldKeyInput_TextChanged(object sender, EventArgs e) {

        }
    }
}
