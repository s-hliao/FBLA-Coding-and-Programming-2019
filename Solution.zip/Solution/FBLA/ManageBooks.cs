﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class ManageBooks : Form {
        public ManageBooks() {
            InitializeComponent();
            

        }

        private void textBox4_TextChanged(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) { //add book
            long x = 0;
            int y =0;
            long k = 0;
            if (newTitle.Text != "" && newAuthor.Text!="" &&newISBN.Text!="" && newCopies.Text!="") {
                bool found = false;
                foreach(Book b in IOMain.FBLALib.bookShelf.Keys) {
                    if (long.TryParse(newISBN.Text, out k)) {
                        if (b.ID ==k) {
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) {
                    if (long.TryParse(newISBN.Text, out x) && int.TryParse(newCopies.Text, out y)) {
                        long[] indexes = new long[y];
                        int count = 0;
                        int index = 0;
                        while (count < y) {
                            if (!IOMain.FBLALib.used[index]) {
                                IOMain.FBLALib.used[index] = true;
                                indexes[count] = index;
                                count++;
                            }
                            index++;

                        } //get all given indexes for the number of books that have not been used
                        IOMain.FBLALib.addBook(x, newTitle.Text, newAuthor.Text, y, y, false, indexes); //insert index
                        Error.Text = "Books added";
                        newTitle.Text = "";
                        newAuthor.Text = "";
                        newISBN.Text = "";
                        newCopies.Text = "";// reset form

                        listView1.Items.Clear();
                        if (IOMain.FBLALib.index != null && IOMain.FBLALib.index.Keys != null) {
                            foreach (int n in IOMain.FBLALib.index.Keys) {
                                string[] display = new string[] { n.ToString(), IOMain.FBLALib.index[n].title.ToString(), IOMain.FBLALib.index[n].ID.ToString(), IOMain.FBLALib.index[n].author };
                                var listViewItem = new ListViewItem(display);
                                listView1.Items.Add(listViewItem);
                            }
                        } // refresh list view
                        IOMain.overwrite(); //overwrite storage
                    } else {
                        Error.Text = "Input not valid";
                    }
                    


                } 
                else {
                    Error.Text = "ISBN already Used";
                }
            }
            else{
                Error.Text = "All Fields Must be filled";
            }
        }

        private void manual_CheckedChanged(object sender, EventArgs e) {

        }

        private void ManageBooks_Load(object sender, EventArgs e) {
            oldID.MaxLength = 10;
            changeID.MaxLength = 10;
            listView1.Items.Clear();
            newISBN.MaxLength = 15;
            copyID.MaxLength = 15;

            if (IOMain.FBLALib.index!=null && IOMain.FBLALib.index.Keys != null) {
                foreach (int x in IOMain.FBLALib.index.Keys) {
                    string[] display = new string[] { x.ToString(), IOMain.FBLALib.index[x].title.ToString(), IOMain.FBLALib.index[x].ID.ToString(), IOMain.FBLALib.index[x].author };
                    var listViewItem = new ListViewItem(display);
                    listView1.Items.Add(listViewItem);
                }
            }// refresh list view
        }

        private void oldID_TextChanged(object sender, EventArgs e) {

        }

        private void button1_Click(object sender, EventArgs e) { //Change the index
            long x = 0;
            long y = 0;
            if(long.TryParse(oldID.Text, out x) && long.TryParse(changeID.Text, out y)) {
                if (IOMain.FBLALib.index!=null && IOMain.FBLALib.index.ContainsKey(x)) {
                    if (!IOMain.FBLALib.index.ContainsKey(y)) {
                        Book b = IOMain.FBLALib.index[x];
                        IOMain.FBLALib.index.Add(y, b); // add the new accession number
                        IOMain.FBLALib.index.Remove(x); // remove the old accession number
                        Error.Text = "ID Changed";
                        oldID.Text = "";
                        changeID.Text = "";

                        listView1.Items.Clear();
                        if (IOMain.FBLALib.index.Keys != null) {
                            foreach (int n in IOMain.FBLALib.index.Keys) {
                                string[] display = new string[] { n.ToString(), IOMain.FBLALib.index[n].title.ToString(),  IOMain.FBLALib.index[n].ID.ToString(), IOMain.FBLALib.index[n].author};
                                var listViewItem = new ListViewItem(display);
                                listView1.Items.Add(listViewItem);
                            }

                        } //refresh list view
                        IOMain.overwrite(); //overwrite stoarage
                    } else {
                        Error.Text = "new ID is already used";
                    }
                } else {
                    Error.Text = "Invalid Shelved ID";
                }
            } else {
                Error.Text = "Invalid input";
            }
            
        }

        private void button3_Click(object sender, EventArgs e) {
            if (copyID.Text != "" && copyCopies.Text != "") { //add copies of book
                long x = 0;
                int y = 0;
                bool found = false;
                if (long.TryParse(copyID.Text, out x) && int.TryParse(copyCopies.Text, out y)) {
                    foreach(Book b in IOMain.FBLALib.bookShelf.Keys) { //find the book
                        if(x==b.ID) {
                            long[] indexes = new long[y];
                            long index = 0;
                            int count = 0;
                            for(int i = 0; i<(Math.Pow(2, 31)-1); i++) {
                                if (IOMain.FBLALib.used[i] == false) {
                                    IOMain.FBLALib.used[i] = true;
                                    indexes[count] = i;
                                    count++;
                                } //find valid accession numbers
                                if (count>=y ) {
                                    break;
                                } //if all all numbers are already found, exit
                            }
                            IOMain.FBLALib.addCopies(b, b.ID, y, indexes); // add the copies to the system
                            break;
                        }
                    }
                    listView1.Items.Clear();
                    if (IOMain.FBLALib.index.Keys != null) {
                        foreach (int n in IOMain.FBLALib.index.Keys) {
                            string[] display = new string[] { n.ToString(), IOMain.FBLALib.index[n].title.ToString(), IOMain.FBLALib.index[n].ID.ToString(), IOMain.FBLALib.index[n].author };
                            var listViewItem = new ListViewItem(display);
                            listView1.Items.Add(listViewItem);
                        }
                    } //update list view
                    copyID.Text = "";
                    copyCopies.Text = "";

                } else {
                    Error.Text = "ID invalid";
                }
            } else {
                Error.Text = "Fields must be filled";
            }
            IOMain.overwrite(); // overwrite data
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e) {
        }
    }
}
