﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FBLA
{


    [Serializable]
    public class Book //class as object book
    {
        public string title;
        public long ID; // ISBN number, unique to books
        public string author; // book data

        public Book(long ID, string title, string author, bool indexUsed)
        {
            this.ID = ID;
            this.title = title;
            this.author = author;
        }

        public override bool Equals(Object o) {
            Book item = o as Book;

            if (item == null) {
                return false;
            }

            return item.ID == this.ID;
            //overwrite equals
        }

        public override int GetHashCode()
        {
            return ID.GetHashCode();
        } // overwrite HashCode
    }

}

