﻿namespace FBLA {
    partial class ManageBooks {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("");
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.oldID = new System.Windows.Forms.TextBox();
            this.Reshelved = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.changeID = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.newTitle = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.newAuthor = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.newISBN = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.newCopies = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.copyCopies = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.copyID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Error = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Title = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ISBN = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Author = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(12, 287);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Manage Books:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(12, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Add Books:";
            // 
            // oldID
            // 
            this.oldID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.oldID.Location = new System.Drawing.Point(127, 327);
            this.oldID.Name = "oldID";
            this.oldID.Size = new System.Drawing.Size(269, 26);
            this.oldID.TabIndex = 2;
            this.oldID.TextChanged += new System.EventHandler(this.oldID_TextChanged);
            // 
            // Reshelved
            // 
            this.Reshelved.AutoSize = true;
            this.Reshelved.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Reshelved.Location = new System.Drawing.Point(30, 330);
            this.Reshelved.Name = "Reshelved";
            this.Reshelved.Size = new System.Drawing.Size(83, 20);
            this.Reshelved.TabIndex = 3;
            this.Reshelved.Text = "Shelved #:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(30, 362);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "New #:";
            // 
            // changeID
            // 
            this.changeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.changeID.Location = new System.Drawing.Point(127, 359);
            this.changeID.Name = "changeID";
            this.changeID.Size = new System.Drawing.Size(269, 26);
            this.changeID.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(152, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 29);
            this.button1.TabIndex = 6;
            this.button1.Text = "Change #";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button2.Location = new System.Drawing.Point(137, 194);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 29);
            this.button2.TabIndex = 11;
            this.button2.Text = "Add Book";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(30, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Title:";
            // 
            // newTitle
            // 
            this.newTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.newTitle.Location = new System.Drawing.Point(127, 64);
            this.newTitle.Name = "newTitle";
            this.newTitle.Size = new System.Drawing.Size(269, 26);
            this.newTitle.TabIndex = 7;
            this.newTitle.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(30, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "Author:";
            // 
            // newAuthor
            // 
            this.newAuthor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.newAuthor.Location = new System.Drawing.Point(127, 98);
            this.newAuthor.Name = "newAuthor";
            this.newAuthor.Size = new System.Drawing.Size(269, 26);
            this.newAuthor.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(30, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "ISBN:";
            // 
            // newISBN
            // 
            this.newISBN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.newISBN.Location = new System.Drawing.Point(127, 130);
            this.newISBN.Name = "newISBN";
            this.newISBN.Size = new System.Drawing.Size(269, 26);
            this.newISBN.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(33, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "# of Copies:";
            // 
            // newCopies
            // 
            this.newCopies.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.newCopies.Location = new System.Drawing.Point(152, 162);
            this.newCopies.Name = "newCopies";
            this.newCopies.Size = new System.Drawing.Size(244, 26);
            this.newCopies.TabIndex = 17;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button3.Location = new System.Drawing.Point(152, 571);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(129, 29);
            this.button3.TabIndex = 23;
            this.button3.Text = "Add Copies";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(30, 531);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 20);
            this.label9.TabIndex = 22;
            this.label9.Text = "# of Copies:";
            // 
            // copyCopies
            // 
            this.copyCopies.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.copyCopies.Location = new System.Drawing.Point(127, 528);
            this.copyCopies.Name = "copyCopies";
            this.copyCopies.Size = new System.Drawing.Size(269, 26);
            this.copyCopies.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.Location = new System.Drawing.Point(30, 499);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 20);
            this.label10.TabIndex = 20;
            this.label10.Text = "ISBN:";
            // 
            // copyID
            // 
            this.copyID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.copyID.Location = new System.Drawing.Point(127, 496);
            this.copyID.Name = "copyID";
            this.copyID.Size = new System.Drawing.Size(269, 26);
            this.copyID.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label11.Location = new System.Drawing.Point(15, 459);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 20);
            this.label11.TabIndex = 24;
            this.label11.Text = "Add Copies:";
            // 
            // Error
            // 
            this.Error.AutoSize = true;
            this.Error.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Error.ForeColor = System.Drawing.Color.Red;
            this.Error.Location = new System.Drawing.Point(37, 629);
            this.Error.Name = "Error";
            this.Error.Size = new System.Drawing.Size(0, 20);
            this.Error.TabIndex = 25;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.Title,
            this.ISBN,
            this.Author});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem2});
            this.listView1.Location = new System.Drawing.Point(435, 67);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(474, 561);
            this.listView1.TabIndex = 27;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Accession #";
            this.columnHeader1.Width = 108;
            // 
            // Title
            // 
            this.Title.Text = "Title";
            this.Title.Width = 102;
            // 
            // ISBN
            // 
            this.ISBN.Text = "ISBN";
            this.ISBN.Width = 91;
            // 
            // Author
            // 
            this.Author.Text = "Author";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(431, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 20);
            this.label4.TabIndex = 28;
            this.label4.Text = "Available Books:";
            // 
            // ManageBooks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 681);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.Error);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.copyCopies);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.copyID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.newCopies);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.newISBN);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.newAuthor);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.newTitle);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.changeID);
            this.Controls.Add(this.Reshelved);
            this.Controls.Add(this.oldID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ManageBooks";
            this.Text = "ManageBooks";
            this.Load += new System.EventHandler(this.ManageBooks_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox oldID;
        private System.Windows.Forms.Label Reshelved;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox changeID;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox newTitle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox newAuthor;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox newISBN;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox newCopies;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox copyCopies;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox copyID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label Error;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Title;
        private System.Windows.Forms.ColumnHeader ISBN;
        private System.Windows.Forms.ColumnHeader Author;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Label label4;
    }
}