﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class Confirmed : Form { //give feedback that an acount is created
        public string lastName;
        public string firstName;
        public int ID;
        public int grade;
        public bool isAdmin;
        public string date;
        public Confirmed(string lastName, string firstName, int ID, int grade, bool isAdmin, string date) {
            InitializeComponent();
            this.lastName = lastName;
            this.firstName = firstName;
            this.ID = ID;
            this.grade = grade;
            this.isAdmin = isAdmin;
            this.date = date;
        }


        private void Confirmed_Load(object sender, EventArgs e) {
            label1.Text = "Name: " + firstName + " "+ lastName;
            label2.Text = "ID: " + ID;
            if (isAdmin) {
                label3.Text = "Admin";
            } else if(grade!=0) {
                label3.Text = "Grade: "+grade;
            } else {
                label3.Text = "Grade: K";
            }
            label4.Text = "Created On: "+ date;
            //create labels with account data
        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void button1_Click(object sender, EventArgs e) {
            this.Close(); // close out of file
        }
    }
}
