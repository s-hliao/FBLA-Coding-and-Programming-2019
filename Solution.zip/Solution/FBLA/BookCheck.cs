﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class BookCheck : Form { //for return and looking at borrowed books

        Account acc;
        public BookCheck(Account a) {
            InitializeComponent();
            acc = a;

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e) {

        }

        private void BookCheck_Load(object sender, EventArgs e) {
            
            acc = IOMain.FBLALib.accounts[acc.studentID]; // read in the account from LibrarySys
            listView1.Items.Clear(); // clear the listview to update items
            Nam.Text = "Checked Out Books: " + acc.firstName + " " + acc.lastName;
            if (acc.checkedBooks.Keys != null && acc.checkedBooks.Keys.Count>0) {
                foreach (Book b in acc.checkedBooks.Keys) {
                    string x = acc.index[b].ToString();
                    string[] display = new string[] { b.title, b.ID.ToString(), b.author, acc.checkedBooks[b], x };
                    var listViewItem = new ListViewItem(display);
                    listView1.Items.Add(listViewItem);
                } // update all items in the listview
            }
        }

        private void button1_Click(object sender, EventArgs e) { // return books to system
            
            for (int i = 0; i < listView1.CheckedItems.Count; i++) { //for all selected listView items
                var selectedItem = (dynamic)listView1.CheckedItems[i];
                if (acc.checkedBooks.Keys.Count>0) { //checking if account does indeed have books
                    foreach (Book b in acc.checkedBooks.Keys) {
                        if (b.ID.ToString() == listView1.CheckedItems[i].SubItems[1].Text) {
                            acc.checkedBooks.Remove(b); // remove from own collection
                            //IOMain.FBLALib.index.Remove(acc.index[b]);
                            bool found = false;
                            long index = 0;
                            while (!found && index<Math.Pow(2, 64)-1) {
                                if (!IOMain.FBLALib.used[index]) {
                                    found = true;
                                    break;
                                }
                                index++;
                            } //search until found
                            IOMain.FBLALib.addCopies(b, b.ID, 1, new long[] { index }); //add back copy of book

                            IOMain.FBLALib.accounts[acc.studentID] = acc; //update locally read account
                            break;
                        }
                    }
                }
            }
            listView1.Items.Clear();
            IOMain.FBLALib.accounts[acc.studentID]= acc;
            if (acc.checkedBooks.Keys != null && acc.checkedBooks.Keys.Count > 0) {
               
                foreach (Book b in acc.checkedBooks.Keys) {
                    string x = acc.index[b].ToString();
                    string[] display = new string[] { b.title, b.ID.ToString(), b.author, acc.checkedBooks[b], x};
                    var listViewItem = new ListViewItem(display);
                    listView1.Items.Add(listViewItem);
                }
            } // update listview display
            IOMain.overwrite();//overwrite data

        }
    }
}
