﻿namespace FBLA {
    partial class AdminKey {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.OldKeyInput = new System.Windows.Forms.TextBox();
            this.AdminLabel = new System.Windows.Forms.Label();
            this.NewAdminLabel = new System.Windows.Forms.Label();
            this.newKeyInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.OldAdminConfirm = new System.Windows.Forms.Label();
            this.ConfirmLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OldKeyInput
            // 
            this.OldKeyInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.OldKeyInput.Location = new System.Drawing.Point(193, 21);
            this.OldKeyInput.Name = "OldKeyInput";
            this.OldKeyInput.Size = new System.Drawing.Size(169, 26);
            this.OldKeyInput.TabIndex = 0;
            this.OldKeyInput.TextChanged += new System.EventHandler(this.OldKeyInput_TextChanged);
            // 
            // AdminLabel
            // 
            this.AdminLabel.AutoSize = true;
            this.AdminLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.AdminLabel.Location = new System.Drawing.Point(12, 21);
            this.AdminLabel.Name = "AdminLabel";
            this.AdminLabel.Size = new System.Drawing.Size(165, 20);
            this.AdminLabel.TabIndex = 1;
            this.AdminLabel.Text = "Enter Old Admin Key:*";
            // 
            // NewAdminLabel
            // 
            this.NewAdminLabel.AutoSize = true;
            this.NewAdminLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.NewAdminLabel.Location = new System.Drawing.Point(12, 56);
            this.NewAdminLabel.Name = "NewAdminLabel";
            this.NewAdminLabel.Size = new System.Drawing.Size(166, 20);
            this.NewAdminLabel.TabIndex = 2;
            this.NewAdminLabel.Text = "Enter New Admin Key:";
            // 
            // newKeyInput
            // 
            this.newKeyInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.newKeyInput.Location = new System.Drawing.Point(193, 56);
            this.newKeyInput.Name = "newKeyInput";
            this.newKeyInput.Size = new System.Drawing.Size(169, 26);
            this.newKeyInput.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(61, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(272, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "*Do not enter a old admin key if setting up";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(126, 134);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 29);
            this.button1.TabIndex = 5;
            this.button1.Text = "Set Admin Key";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // OldAdminConfirm
            // 
            this.OldAdminConfirm.AutoSize = true;
            this.OldAdminConfirm.Location = new System.Drawing.Point(369, 27);
            this.OldAdminConfirm.Name = "OldAdminConfirm";
            this.OldAdminConfirm.Size = new System.Drawing.Size(0, 13);
            this.OldAdminConfirm.TabIndex = 6;
            // 
            // ConfirmLabel
            // 
            this.ConfirmLabel.AutoSize = true;
            this.ConfirmLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ConfirmLabel.Location = new System.Drawing.Point(80, 200);
            this.ConfirmLabel.Name = "ConfirmLabel";
            this.ConfirmLabel.Size = new System.Drawing.Size(0, 20);
            this.ConfirmLabel.TabIndex = 7;
            // 
            // AdminKey
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 261);
            this.Controls.Add(this.ConfirmLabel);
            this.Controls.Add(this.OldAdminConfirm);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.newKeyInput);
            this.Controls.Add(this.NewAdminLabel);
            this.Controls.Add(this.AdminLabel);
            this.Controls.Add(this.OldKeyInput);
            this.Name = "AdminKey";
            this.Text = "AdminKey";
            this.Load += new System.EventHandler(this.AdminKey_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox OldKeyInput;
        private System.Windows.Forms.Label AdminLabel;
        private System.Windows.Forms.Label NewAdminLabel;
        private System.Windows.Forms.TextBox newKeyInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label OldAdminConfirm;
        private System.Windows.Forms.Label ConfirmLabel;
    }
}