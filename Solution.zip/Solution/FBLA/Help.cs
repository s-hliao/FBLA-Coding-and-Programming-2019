﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class Help : Form { //[reprepared answer to questions
        public Help() {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { //answers to questions change based on selected index of FAQ
            if (comboBox1.SelectedIndex == 0) {
                Answer.Text = @"Go to Check Out books, and ask an administrator for 
an Accession Number from their list of books.";
            } else if(comboBox1.SelectedIndex == 1) {
                Answer.Text = @"As an administrator, go to Add and manage books, and 
to add a book to add a new book, or add copies 
with a previously existing book.";
            } else if (comboBox1.SelectedIndex == 2) {
                Answer.Text = @"Enter their ID from the list into the studentID 
search bar, the select the action to be taken";
            } else if (comboBox1.SelectedIndex == 3) {
                Answer.Text = @"Checkout emails search in the library whereas return
emails search in accounts. Outlook is necessary 
for this to work";
            } else if (comboBox1.SelectedIndex == 4) {
                Answer.Text = @"Reports come in the form of excel files. As such, excel 
must be installed for this to wokr. Each sheet is 
labeled with a student, containing their account 
and checkout information, as well as previous used 
accession numbers.";
            } else if (comboBox1.SelectedIndex == 5) {
                Answer.Text = @"Click return to Login";
            } else if (comboBox1.SelectedIndex == 6) {
                Answer.Text = @"If an admin, click reset and enter the admin key, 
the click reset to confirm";
            } else {
                Answer.Text = @"Exit and copy the json file 'lib.json' transfer it to
the same spot after downloading this program 
onto another computer";
            }
        }

        private void Help_Load(object sender, EventArgs e) {
            
        }
    }
}
