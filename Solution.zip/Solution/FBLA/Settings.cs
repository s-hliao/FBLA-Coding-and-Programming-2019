﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class Settings : Form { //display account settings and change passwords
        public Account acc;
        public Settings(Account a) {
            this.acc = a;
            InitializeComponent();
        }

        private void Settings_Load(object sender, EventArgs e) {
            Nam.Text = "Name: "+acc.firstName + " " + acc.lastName;
            Identity.Text = "ID: " + acc.studentID;
            Date.Text = "Date Created: " + acc.dateCreated;
            if (acc.isAdmin) {
                Grade.Text = "Admin";
            } else if (acc.grade == 0) {
                Grade.Text = "Grade Level: K";
            }
            else{
                Grade.Text = "Grade Level: "+acc.grade;
            } // display data
            Confirm.PasswordChar = '*';
            Original.PasswordChar = '*';
            Change.PasswordChar = '*'; // hide passwords
       }

        private void button1_Click(object sender, EventArgs e) {
            if (Original.Text == acc.password) {
                if (Change.Text == Confirm.Text) {
                    if (Change.Text.Length < 5) {
                        label2.Text = "Passwords must be greater than 5 characters";
                    } else {
                        IOMain.FBLALib.accounts[acc.studentID].password = Confirm.Text; //replace account with new passowrd
                        acc = IOMain.FBLALib.accounts[acc.studentID];
                        label2.Text = "Password Changed";
                        Confirm.Text = "";
                        Original.Text = "";
                        Change.Text = "";
                        IOMain.overwrite(); //overwrite data

                    }
                 } else {
                    label2.Text = "Passwords do not match";
                }
            } 
            else {
                label2.Text = "Incorrect Original Password";
            }
        }
 

        private void label5_Click(object sender, EventArgs e) {

        }
    }
}
