﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FBLA {
    public partial class ManageStudent : Form {
        public ManageStudent() {
            InitializeComponent();
        }

        private void ManageStudent_Load(object sender, EventArgs e) {
            foreach (int i in IOMain.FBLALib.accounts.Keys) { //use all accounts
                if (!IOMain.FBLALib.accounts[i].isAdmin) {
                    if (IOMain.FBLALib.accounts[i].grade == 0) {
                        string[] display = new string[] { i.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, "K", IOMain.FBLALib.accounts[i].dateCreated };
                        var listViewItem = new ListViewItem(display);
                        listView1.Items.Add(listViewItem); //add to listview as Kindergardener
                    } else {
                        string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, IOMain.FBLALib.accounts[i].grade.ToString(), IOMain.FBLALib.accounts[i].dateCreated };
                        var listViewItem = new ListViewItem(display);
                        listView1.Items.Add(listViewItem); //add to listview as student
                    }
                }
                else {
                    string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, "Admin", IOMain.FBLALib.accounts[i].dateCreated };
                    var listViewItem = new ListViewItem(display);
                    listView1.Items.Add(listViewItem); //add to list view as admin
                }
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            long x = 0;
            if (long.TryParse(ID.Text, out x)) {
                bool found = false;
                Account acc = null;
                foreach(int i in IOMain.FBLALib.accounts.Keys) {
                    if (IOMain.FBLALib.accounts[i].studentID == x) {
                        acc = IOMain.FBLALib.accounts[i];
                        found = true;
                        break; // search for the account by ID
                    }
                }
                if (found) {
                    BookCheck studentText = new BookCheck(acc);
                    studentText.Show();  //show checked out books for given account
                } else {
                    Error.Text = "No Such ID";
                }
            } else{
                Error.Text = "Invalid ID";
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            long x = 0;
            if (long.TryParse(ID.Text, out x)) {
                bool found = false;
                Account acc = null;
                foreach (int i in IOMain.FBLALib.accounts.Keys) {
                    if (i == x) {
                        acc = IOMain.FBLALib.accounts[i];
                        found = true;
                        break;// search for the account by ID
                    }
                }
                if (found) {
                    StudentSettings studentText = new StudentSettings(acc, this); //open full setting changes for account
                    studentText.Show();
                } else {
                    Error.Text = "No Such ID";
                }
            } else {
                Error.Text = "Invalid ID";
            }
        }

        private void button3_Click(object sender, EventArgs e) {
            update();
        }
        public void update() {
            listView1.Items.Clear();
            foreach (int i in IOMain.FBLALib.accounts.Keys) {
                if (!IOMain.FBLALib.accounts[i].isAdmin) {
                    if (IOMain.FBLALib.accounts[i].grade == 0) {
                        string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, "K", IOMain.FBLALib.accounts[i].dateCreated };
                        var listViewItem = new ListViewItem(display);
                        listView1.Items.Add(listViewItem);
                        //add kindergardeners to listview
                    } else {
                        string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, IOMain.FBLALib.accounts[i].grade.ToString(), IOMain.FBLALib.accounts[i].dateCreated };
                        var listViewItem = new ListViewItem(display);
                        listView1.Items.Add(listViewItem);
                        //add students to listview
                    }
                } else {
                    string[] display = new string[] { IOMain.FBLALib.accounts[i].studentID.ToString(), IOMain.FBLALib.accounts[i].firstName, IOMain.FBLALib.accounts[i].lastName, "Admin", IOMain.FBLALib.accounts[i].dateCreated };
                    var listViewItem = new ListViewItem(display);
                    listView1.Items.Add(listViewItem);
                    //add admin to listview
                }
            }
        }
    }
}
